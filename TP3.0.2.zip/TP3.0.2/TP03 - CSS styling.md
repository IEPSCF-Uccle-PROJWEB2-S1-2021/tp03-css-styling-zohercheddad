Consignes


1° Polices

 Cherchez sur Google Fonts 2 polices de caractères. Vous avez besoin d'une police serif comme police par défaut pour tout le site que vous couplerez à une police sans-serif pour les titres.
 Insérez le lien adéquat dans votre document HTML pour charger ces polices.
 Appliquez votre police pour le texte général à la page complète et la police pour les titres aux titres.



2° Mise en forme générale
 
Donnez à la page en général une font-size de 10px.
Donnez à vos titres et aux autres types d'éléments des tailles de police appropriées en les définissant à l'aide d'unités relatives.
Donnez à votre corps de texte une line-height appropriée.
Centrez votre titre principal sur la page.
Donnez à vos titres un petit peu de letter-spacing pour qu'elles ne soient pas trop écrasées
Donnez à votre corps de   texte   un peu de  l e t t e r-s p a c i n g  et de word-spacing, par cas.
  Après chaque titre de la <section>, indentez la première ligne du premier paragraph,de 20px.
 
Liens
 Donnez aux états link, visited, focus et hover quelques couleurs qui vont avec la couleur des barres horizontales en haut et en bas de la page.
 Faites en sorte que les liens soient soulignés par défaut, mais lorsque vous les survolez ou qu'ils reçoivent le focus, le soulignement disparait.
 Supprimez la bordure pointillée que les liens ont par défaut lorsqu'ils reçoivent le focus pour 
Supprimez la bordure pointillée que les liens ont par défaut lorsqu'ils reçoivent le focus pour TOUS les liens.




TP03 - CSS styling
Vous trouverez dans ce répertoire :

un document HTML
une feuille de style
une icône pour les liens externes
Votre objectif est de modifier la feuille de style de manière à ce que votre page ressemble à celle de l'image ci-dessous. Essayez de résoudre cet exercice sans modifier le document HTML (sauf pour le chargement des polices).

Résultat final

Vous aurez besoin de faire appel à des sélecteurs et des propriétés que nous n'avons pas abordés dans les révisions. Vous trouverez des réponses à vos questions en consultant les liens suivants :

Référence CSS Mozilla
Référence CSS w3schools.com
Consignes
Polices
 Cherchez sur Google Fonts 2 polices de caractères. Vous avez besoin d'une police serif comme police par défaut pour tout le site que vous couplerez à une police sans-serif pour les titres.
 Insérez le lien adéquat dans votre document HTML pour charger ces polices.
 Appliquez votre police pour le texte général à la page complète et la police pour les titres aux titres.
Mise en forme générale
 Donnez à la page en général une font-size de 10px.
 Donnez à vos titres et aux autres types d'éléments des tailles de police appropriées en les définissant à l'aide d'unités relatives.
 Donnez à votre corps de texte une line-height appropriée.
 Centrez votre titre principal sur la page.
 Donnez à vos titres un petit peu de letter-spacing pour qu'elles ne soient pas trop écrasées et laissez les lettres respirer un peu.
 Donnez à votre corps de texte un peu de letter-spacing et de word-spacing, selon le cas.
 Après chaque titre de la <section>, indentez la première ligne du premier paragraph, disons de 20px.
Liens
 Donnez aux états link, visited, focus et hover quelques couleurs qui vont avec la couleur des barres horizontales en haut et en bas de la page.
 Faites en sorte que les liens soient soulignés par défaut, mais lorsque vous les survolez ou qu'ils reçoivent le focus, le soulignement disparait.
 Supprimez la bordure pointillée que les liens ont par défaut lorsqu'ils reçoivent le focus pour TOUS les liens.
 Donnez à l'état active un style sensiblement différent pour qu'il se démarque bien, mais faites en sorte qu'il s'intègre toujours dans le design global de la page.
 Faites en sorte que l'icône de lien externe (les liens dont href commence par http) soit insérée à côté des liens externes.
Listes
 Assurez-vous que l'espacement de vos listes et de vos éléments de liste s'intègre bien au style de l'ensemble de la page. Chaque élément de liste doit avoir la même hauteur de ligne qu'une ligne de paragraphe, et chaque liste doit avoir le même expacement en haut et en bas que celui que vous avez entre les paragraphes.
 Donnez à vos éléments une jolie puce, adaptée au style de la page. C'est à vous de choisir une image de puce personnalisée ou autre chose.
Menu de navigation
 Donnez à votre menu de navigation un style qui convient à l'aspect et à la la convivialité de la page.
Trucs et astuces
À part pour le chargement des polices, vous n'avez pas besoin de modifier le document HTML pour réussir cet exercice.
Vous ne devez pas forcément faire ressembler le menu de navigation à des boutons, mais les liens doivent être un peu plus haut pour ne pas qu'ils aient l'air ridicules sur le côté de la page; rappelez-vous aussi que vous devez rendre ce menu de navigation vertical.
Faites fonctionner l'intelligence collective. Je vous ai créé ce canal dans Teams pour essayer ensemble de répondre à vos questions et pour échangez vos propres trucs et astuces.